<?php
// Copy the 'paypal' array into the 'services' array in config/services.php.
'paypal' => [
    'mode' => env('PAYPAL_MODE', 'sandbox'),
    'client_id' => env('PAYPAL_CLIENT_ID'),
    'client_secret' => env('PAYPAL_CLIENT_SECRET'),
    'currency' => env('PAYPAL_CURRENCY', 'USD'),
    'product_name' => env('PAYPAL_PRODUCT_NAME', 'Premium Demo Subscription'),
    'amount' => env('PAYPAL_PRODUCT_AMOUNT', '49.00'),
],
